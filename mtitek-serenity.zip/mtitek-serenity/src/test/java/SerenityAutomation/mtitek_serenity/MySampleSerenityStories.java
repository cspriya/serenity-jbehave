package SerenityAutomation.mtitek_serenity;


import net.serenitybdd.jbehave.SerenityStories;

public class MySampleSerenityStories extends SerenityStories {
}
