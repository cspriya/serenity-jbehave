package SerenityAutomation.mtitek_serenity;

import org.jbehave.core.annotations.*;
public class MySampleTest1{
	@When("the user looks up the definition of the word 'apple'")
	
	public void whenTheUserLooksUpTheDefinitionOfTheWordapple(){
		 System.out.println("first run1");
	}
	@Then("they should see the definition 'A common, round fruit produced by the tree Malus domestica, cultivated in temperate climates.'")
	
	public void thenTheyShouldSeeTheDefinitionACommonRoundFruitProducedByTheTreeMalusDomesticaCultivatedInTemperateClimates(){
		System.out.println("first run2");
	}
	@Given("the user is on the Wikionary home page")
	
	public void givenTheUserIsOnTheWikionaryHomePage(){
		System.out.println("first run3");
		 
	}
}